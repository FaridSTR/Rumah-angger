extends CharacterBody3D

var target: Node3D
var speed := 1.65
var tick := 0.0

func _ready():
    var body = MeshInstance3D.new()
    var mesh = CapsuleMesh.new()
    mesh.radius = 0.48
    mesh.height = 2.2
    body.mesh = mesh
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.055,0.045,0.065)
    mat.emission_enabled = true
    mat.emission = Color(0.12,0.015,0.025)
    body.material_override = mat
    body.position.y = 1.1
    add_child(body)
    var eyes = MeshInstance3D.new()
    var eye_mesh = SphereMesh.new()
    eye_mesh.radius = 0.075
    eye_mesh.height = 0.15
    eyes.mesh = eye_mesh
    var eye_mat = StandardMaterial3D.new()
    eye_mat.albedo_color = Color(1,0.02,0.01)
    eye_mat.emission_enabled = true
    eye_mat.emission = Color(1,0,0)
    eyes.material_override = eye_mat
    eyes.position = Vector3(0.17,1.45,-0.42)
    add_child(eyes)
    var eyes2 = eyes.duplicate()
    eyes2.position.x = -0.17
    add_child(eyes2)
    var c = CollisionShape3D.new()
    var s = CapsuleShape3D.new()
    s.radius = 0.42
    s.height = 2.0
    c.shape = s
    c.position.y = 1
    add_child(c)

func _physics_process(delta):
    if not target:
        target = get_tree().get_first_node_in_group("player")
        if not target:
            var candidates = get_tree().current_scene.get_children()
            for n in candidates:
                if n is CharacterBody3D and n != self:
                    target = n
                    break
    if target:
        var d = target.global_position - global_position
        d.y = 0
        if d.length() > 1.7:
            velocity.x = d.normalized().x * speed
            velocity.z = d.normalized().z * speed
            look_at(Vector3(target.global_position.x,global_position.y,target.global_position.z))
        else:
            velocity.x = 0
            velocity.z = 0
        if not is_on_floor(): velocity.y -= 18*delta
        else: velocity.y = -0.1
        move_and_slide()
