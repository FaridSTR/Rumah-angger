extends Node3D

const PlayerScript = preload("res://scripts/player.gd")
const GhostScript = preload("res://scripts/ghost.gd")
var player
var message_label: Label
var objective_label: Label
var scare_timer := 0.0
var collected := 0
var keys_total := 3
var ghost
var ambience: AudioStreamPlayer
var scare_audio: AudioStreamPlayer

func _ready():
    _build_world()
    _build_ui()
    ambience = AudioStreamPlayer.new()
    ambience.stream = load("res://assets/audio/night_wind.wav")
    ambience.volume_db = -13.0
    ambience.autoplay = true
    add_child(ambience)
    ambience.finished.connect(func(): ambience.play())
    scare_audio = AudioStreamPlayer.new()
    scare_audio.stream = load("res://assets/audio/ghost_sting.wav")
    scare_audio.volume_db = -7.0
    add_child(scare_audio)
    player = CharacterBody3D.new()
    player.set_script(PlayerScript)
    player.position = Vector3(0, 0.15, 10)
    add_child(player)
    ghost = CharacterBody3D.new()
    ghost.set_script(GhostScript)
    ghost.position = Vector3(0, 0, -13)
    add_child(ghost)
    _say("Cari 3 kunci di sekitar desa. Jangan biarkan ANGGER mendekat.")
    _update_objective()

func _process(delta):
    scare_timer += delta
    if scare_timer > 32.0:
        scare_timer = 0
        _say("Ada sesuatu yang sedang mengawasimu...")
    if is_instance_valid(ghost) and player:
        if ghost.global_position.distance_to(player.global_position) < 2.0:
            _say("ANGGER MENEMUKANMU! Lari!")
            if scare_audio and not scare_audio.playing: scare_audio.play()
            player.health = max(0, player.health - 1)
            ghost.global_position = Vector3(randf_range(-15,15), 0, randf_range(-18,18))
            if player.health <= 0:
                _say("KAMU TERTANGKAP. Tekan tombol ulang untuk mencoba lagi.")

func _build_world():
    var env = WorldEnvironment.new()
    var e = Environment.new()
    e.background_mode = Environment.BG_SKY
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.16,0.17,0.22)
    e.ambient_light_energy = 0.22
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    e.fog_enabled = true
    e.fog_light_color = Color(0.12,0.13,0.16)
    e.fog_density = 0.035
    env.environment = e
    add_child(env)
    var moon = DirectionalLight3D.new()
    moon.rotation_degrees = Vector3(-55,-25,0)
    moon.light_color = Color(0.48,0.52,0.72)
    moon.light_energy = 0.22
    moon.shadow_enabled = true
    add_child(moon)
    _box("Tanah", Vector3(0,-0.6,0), Vector3(70,1,70), Color(0.10,0.12,0.09))
    # village road
    _box("Jalan desa", Vector3(0,-0.05,0), Vector3(5,0.12,55), Color(0.20,0.19,0.17))
    # houses, shop, and abandoned structures
    _house(Vector3(-9,0,-7), "RUMAH KOSONG", Color(0.28,0.23,0.19))
    _house(Vector3(10,0,-11), "RUMAH ANGGER", Color(0.22,0.16,0.17))
    _shop(Vector3(-11,0,12))
    _house(Vector3(12,0,13), "GUDANG", Color(0.24,0.25,0.21))
    # trees and roadside props
    for i in range(34):
        var x = randf_range(-29,29)
        var z = randf_range(-27,27)
        if abs(x) < 4.5: continue
        _tree(Vector3(x,0,z))
    for i in range(8):
        _box("Pagar", Vector3(-5.5 + i*1.55,0.45,4), Vector3(0.12,0.9,0.12), Color(0.22,0.16,0.12))
    # collectible keys
    for p in [Vector3(-8,0.7,-4), Vector3(-10,0.7,15), Vector3(12,0.7,15)]:
        _key(p)

func _mat(c: Color):
    var m = StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 0.95
    return m

func _box(n, pos, size, color):
    var b = StaticBody3D.new()
    b.name = n
    b.position = pos
    var mesh = MeshInstance3D.new()
    var shape_mesh = BoxMesh.new()
    shape_mesh.size = size
    mesh.mesh = shape_mesh
    mesh.material_override = _mat(color)
    b.add_child(mesh)
    var col = CollisionShape3D.new()
    var shape = BoxShape3D.new()
    shape.size = size
    col.shape = shape
    b.add_child(col)
    add_child(b)
    return b

func _house(pos: Vector3, title: String, color: Color):
    _box(title+" dinding", pos+Vector3(0,1.5,0), Vector3(6,3,5), color)
    _box("Atap", pos+Vector3(0,3.35,0), Vector3(6.8,0.35,5.8), Color(0.12,0.10,0.11))
    _box("Pintu", pos+Vector3(0,1,2.56), Vector3(1.1,2,0.12), Color(0.09,0.055,0.04))
    _box("Jendela", pos+Vector3(-2,1.8,2.58), Vector3(1,0.8,0.12), Color(0.025,0.04,0.06))
    _box("Jendela", pos+Vector3(2,1.8,2.58), Vector3(1,0.8,0.12), Color(0.025,0.04,0.06))

func _shop(pos: Vector3):
    _box("TOKO - bangunan", pos+Vector3(0,1.5,0), Vector3(7,3,5), Color(0.29,0.25,0.17))
    _box("Kanopi toko", pos+Vector3(0,2.8,2.8), Vector3(8,0.25,1.4), Color(0.38,0.12,0.10))
    _box("Etalase", pos+Vector3(0,1,2.56), Vector3(3.5,1.2,0.12), Color(0.08,0.12,0.13))

func _tree(pos: Vector3):
    var trunk = MeshInstance3D.new()
    var cyl = CylinderMesh.new()
    cyl.height = 3.5
    cyl.top_radius = 0.18
    cyl.bottom_radius = 0.32
    trunk.mesh = cyl
    trunk.position = pos+Vector3(0,1.5,0)
    trunk.material_override = _mat(Color(0.16,0.10,0.07))
    add_child(trunk)
    var crown = MeshInstance3D.new()
    var sphere = SphereMesh.new()
    sphere.radius = 1.7
    sphere.height = 3.2
    crown.mesh = sphere
    crown.position = pos+Vector3(0,3.7,0)
    crown.material_override = _mat(Color(0.035,0.075,0.045))
    add_child(crown)

func _key(pos):
    var a = Area3D.new()
    a.position = pos
    a.set_meta("is_key", true)
    var mesh = MeshInstance3D.new()
    var torus = TorusMesh.new()
    torus.inner_radius = 0.12
    torus.outer_radius = 0.22
    mesh.mesh = torus
    mesh.material_override = _mat(Color(0.95,0.68,0.16))
    a.add_child(mesh)
    var col = CollisionShape3D.new()
    var s = SphereShape3D.new()
    s.radius = 0.8
    col.shape = s
    a.add_child(col)
    a.body_entered.connect(_on_key_body.bind(a))
    add_child(a)

func _on_key_body(body, area):
    if body == player and area.get_parent() != null:
        area.queue_free()
        collected += 1
        _update_objective()
        _say("Kunci ditemukan! ("+str(collected)+"/"+str(keys_total)+")")
        if collected == keys_total:
            _say("Semua kunci terkumpul! Gerbang keluar terbuka — cari jalan pulang.")

func _build_ui():
    var layer = CanvasLayer.new()
    add_child(layer)
    var panel = VBoxContainer.new()
    panel.position = Vector2(18,15)
    layer.add_child(panel)
    objective_label = Label.new()
    objective_label.add_theme_font_size_override("font_size", 22)
    panel.add_child(objective_label)
    message_label = Label.new()
    message_label.position = Vector2(0,36)
    message_label.add_theme_font_size_override("font_size", 18)
    panel.add_child(message_label)
    var help = Label.new()
    help.text = "WASD / joystick: jalan   |   E: interaksi   |   F: senter   |   SHIFT: lari"
    help.position = Vector2(18, get_viewport().get_visible_rect().size.y-35)
    help.add_theme_font_size_override("font_size", 15)
    layer.add_child(help)

func _update_objective():
    if objective_label:
        objective_label.text = "RUMAH ANGGER  |  KUNCI: %d/%d  |  NYAWA: %d" % [collected, keys_total, player.health if player else 3]

func _say(t):
    if message_label:
        message_label.text = t
        await get_tree().create_timer(4.0).timeout
        if is_instance_valid(message_label) and message_label.text == t:
            message_label.text = ""
