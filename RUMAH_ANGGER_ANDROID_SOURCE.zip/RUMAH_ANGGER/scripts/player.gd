extends CharacterBody3D

var speed := 4.0
var run_speed := 6.8
var health := 3
var look_sensitivity := 0.0025
var pitch := 0.0
var flashlight_on := true
var camera: Camera3D
var lamp: SpotLight3D
var hud: CanvasLayer
var joy_origin := Vector2.ZERO
var joy_vector := Vector2.ZERO
var dragging_look := false
var last_touch := Vector2.ZERO

func _ready():
    var col = CollisionShape3D.new()
    var capsule = CapsuleShape3D.new()
    capsule.height = 1.7
    capsule.radius = 0.34
    col.shape = capsule
    col.position.y = 0.85
    add_child(col)
    camera = Camera3D.new()
    camera.position.y = 1.55
    camera.current = true
    add_child(camera)
    lamp = SpotLight3D.new()
    lamp.position = Vector3(0,0,-0.15)
    lamp.spot_range = 19
    lamp.spot_angle = 38
    lamp.light_energy = 3.2
    lamp.shadow_enabled = true
    camera.add_child(lamp)
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if not OS.has_feature("mobile") else Input.MOUSE_MODE_VISIBLE
    _make_mobile_controls()

func _unhandled_input(event):
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        rotate_y(-event.relative.x * look_sensitivity)
        pitch = clamp(pitch - event.relative.y * look_sensitivity, -1.25, 1.25)
        camera.rotation.x = pitch
    if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x > get_viewport().size.x * 0.38:
                dragging_look = true
                last_touch = event.position
        else:
            dragging_look = false
    if event is InputEventScreenDrag and dragging_look:
        var d = event.position - last_touch
        last_touch = event.position
        rotate_y(-d.x * 0.004)
        pitch = clamp(pitch - d.y * 0.004, -1.25, 1.25)
        camera.rotation.x = pitch

func _physics_process(delta):
    var input_vec = Input.get_vector("move_left","move_right","move_forward","move_back")
    if joy_vector.length() > 0.1:
        input_vec = joy_vector
    var direction = (transform.basis * Vector3(input_vec.x,0,input_vec.y)).normalized()
    var moving = direction.length() > 0.1
    var current_speed = run_speed if Input.is_action_pressed("run") else speed
    if moving:
        velocity.x = direction.x * current_speed
        velocity.z = direction.z * current_speed
    else:
        velocity.x = move_toward(velocity.x,0,18*delta)
        velocity.z = move_toward(velocity.z,0,18*delta)
    if not is_on_floor():
        velocity.y -= 18*delta
    else:
        velocity.y = -0.2
    move_and_slide()
    if Input.is_action_just_pressed("flashlight"):
        toggle_flashlight()

func toggle_flashlight():
    flashlight_on = not flashlight_on
    lamp.visible = flashlight_on

func _make_mobile_controls():
    hud = CanvasLayer.new()
    add_child(hud)
    var run_btn = _button("LARI", Vector2(-150,-105), Vector2(125,55))
    run_btn.button_down.connect(func(): Input.action_press("run"))
    run_btn.button_up.connect(func(): Input.action_release("run"))
    var light_btn = _button("SENTER", Vector2(-150,-175), Vector2(125,55))
    light_btn.pressed.connect(toggle_flashlight)
    var move_btn = _button("MAJU", Vector2(25,-115), Vector2(105,55))
    move_btn.button_down.connect(func(): joy_vector = Vector2(0,-1))
    move_btn.button_up.connect(func(): joy_vector = Vector2.ZERO)
    var back_btn = _button("MUNDUR", Vector2(25,-55), Vector2(105,55))
    back_btn.button_down.connect(func(): joy_vector = Vector2(0,1))
    back_btn.button_up.connect(func(): joy_vector = Vector2.ZERO)
    var left_btn = _button("◀", Vector2(0,-55), Vector2(55,55))
    left_btn.button_down.connect(func(): joy_vector = Vector2(-1,0))
    left_btn.button_up.connect(func(): joy_vector = Vector2.ZERO)
    var right_btn = _button("▶", Vector2(135,-55), Vector2(55,55))
    right_btn.button_down.connect(func(): joy_vector = Vector2(1,0))
    right_btn.button_up.connect(func(): joy_vector = Vector2.ZERO)

func _button(label_text, offset, size):
    var b = Button.new()
    b.text = label_text
    b.position = Vector2(get_viewport().size.x + offset.x, get_viewport().size.y + offset.y)
    b.size = size
    b.add_theme_font_size_override("font_size", 16)
    hud.add_child(b)
    return b
