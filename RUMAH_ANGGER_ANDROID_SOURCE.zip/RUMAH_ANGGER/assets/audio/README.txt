Original procedurally generated ambience/effect WAV files. Integrate into AudioStreamPlayer nodes in the next audio pass.
