# RUMAH ANGGER

Game horor first-person 3D untuk Android, dibuat dengan Godot 4.3 (GDScript).

## Isi prototype
- Desa malam berkabut dengan rumah kosong, Rumah Angger, toko, gudang, jalan, dan pepohonan.
- Sudut pandang orang pertama, senter, kontrol keyboard/mouse dan tombol layar sentuh.
- Hantu ANGGER yang mengejar pemain.
- Tiga kunci untuk objektif eksplorasi.
- Rendering GL Compatibility agar lebih ramah perangkat mobile.

## Build APK lewat GitHub
1. Buat repository GitHub baru.
2. Upload seluruh isi folder ZIP ini ke root repository.
3. Buka tab **Actions** dan jalankan workflow **Build Android APK** (atau push ke branch `main`).
4. Tunggu workflow selesai, lalu unduh artifact `rumah-angger-android-debug`.

Workflow memakai Godot 4.3 dan Android export templates. APK yang dihasilkan adalah **debug APK** untuk pengujian. Untuk rilis Play Store, siapkan keystore sendiri dan konfigurasi signing release.

## Build lokal
Install Godot 4.3, Android SDK/JDK dan export templates Android. Tambahkan Android export preset bernama `Android`, lalu jalankan:
`godot --headless --path . --export-debug Android RumahAngger.apk`

## Kontrol
- PC: WASD bergerak, mouse melihat, Shift berlari, F senter.
- Android: tombol MAJU/MUNDUR/kiri/kanan, geser sisi kanan layar untuk melihat, tombol LARI dan SENTER.

## Catatan
Ini adalah fondasi game/prototype playable dengan lingkungan 3D procedural. Model karakter, animasi, voice acting, musik, cutscene, dan level cerita penuh masih perlu diproduksi/ditambahkan pada tahap pengembangan berikutnya.
